
import React from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Label } from 'recharts';
import type { ChartDataPoint } from '../types';
import { DEFAULT_CURRENCY } from '../constants';

interface ChartRendererProps {
  data: ChartDataPoint[];
  type: 'line' | 'bar';
  xDataKey: string;
  yDataKeys: { key: string; color: string; name?: string }[];
  title?: string;
  yAxisLabel?: string;
  xAxisLabel?: string;
}

const ChartRenderer: React.FC<ChartRendererProps> = ({ data, type, xDataKey, yDataKeys, title, yAxisLabel, xAxisLabel }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full p-4 text-center">
        <p className="text-lg text-slate-500 italic">No data to display for the current inputs.</p>
      </div>
    );
  }
  
  const formatYAxisTick = (value: number) => {
    if (Math.abs(value) >= 1000000) return `${DEFAULT_CURRENCY}${(value / 1000000).toFixed(1)}M`;
    if (Math.abs(value) >= 1000) return `${DEFAULT_CURRENCY}${(value / 1000).toFixed(1)}K`;
    return `${DEFAULT_CURRENCY}${value.toFixed(0)}`;
  };

  const chartMargin = { top: 5, right: 20, left: yAxisLabel ? 35 : 25, bottom: xAxisLabel ? 25 : 5 };


  return (
    <div className="p-4 bg-slate-800 rounded-lg shadow-md h-full"> {/* Changed height to h-full for flexibility */}
      {title && <h3 className="text-xl font-semibold mb-6 text-center text-slate-100">{title}</h3>}
      <ResponsiveContainer width="100%" height="100%">
        {type === 'line' ? (
          <LineChart data={data} margin={chartMargin}>
            <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
            <XAxis dataKey={xDataKey} stroke="#94a3b8" tick={{ fontSize: 12 }}>
              {xAxisLabel && <Label value={xAxisLabel} offset={-18} position="insideBottom" fill="#94a3b8" fontSize={14} />}
            </XAxis>
            <YAxis stroke="#94a3b8" tickFormatter={formatYAxisTick} tick={{ fontSize: 12 }} domain={['auto', 'auto']}>
              {yAxisLabel && <Label value={yAxisLabel} angle={-90} position="insideLeft" style={{ textAnchor: 'middle' }} fill="#94a3b8" fontSize={14} offset={-10}/>}
            </YAxis>
            <Tooltip
              contentStyle={{ backgroundColor: 'rgba(30, 41, 59, 0.95)', border: '1px solid #334155', borderRadius: '0.5rem', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}
              labelStyle={{ color: '#cbd5e1', fontWeight: 'bold', marginBottom: '4px', display: 'block' }}
              itemStyle={{ color: '#94a3b8' }}
              formatter={(value: number, name: string, props) => [`${DEFAULT_CURRENCY}${value.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, props.name]}
            />
            <Legend wrapperStyle={{ color: '#cbd5e1', paddingTop: '10px' }} />
            {yDataKeys.map(item => (
              <Line key={item.key} type="monotone" dataKey={item.key} name={item.name || item.key} stroke={item.color} strokeWidth={2.5} dot={{ r: 3, strokeWidth: 1, fill: item.color }} activeDot={{ r: 7, strokeWidth: 2, stroke: '#fff' }} />
            ))}
          </LineChart>
        ) : (
          <BarChart data={data} margin={chartMargin} barGap={4} barCategoryGap="20%">
            <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
            <XAxis dataKey={xDataKey} stroke="#94a3b8" tick={{ fontSize: 12 }}>
              {xAxisLabel && <Label value={xAxisLabel} offset={-18} position="insideBottom" fill="#94a3b8" fontSize={14} />}
            </XAxis>
            <YAxis stroke="#94a3b8" tickFormatter={formatYAxisTick} tick={{ fontSize: 12 }} domain={['auto', 'auto']}>
             {yAxisLabel && <Label value={yAxisLabel} angle={-90} position="insideLeft" style={{ textAnchor: 'middle' }} fill="#94a3b8" fontSize={14} offset={-10}/>}
            </YAxis>
            <Tooltip
              contentStyle={{ backgroundColor: 'rgba(30, 41, 59, 0.95)', border: '1px solid #334155', borderRadius: '0.5rem', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}
              labelStyle={{ color: '#cbd5e1', fontWeight: 'bold', marginBottom: '4px', display: 'block' }}
              itemStyle={{ color: '#94a3b8' }}
              formatter={(value: number, name: string, props) => [`${DEFAULT_CURRENCY}${value.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, props.name]}
            />
            <Legend wrapperStyle={{ color: '#cbd5e1', paddingTop: '10px' }} />
            {yDataKeys.map(item => (
              <Bar key={item.key} dataKey={item.key} name={item.name || item.key} fill={item.color} radius={[4, 4, 0, 0]} />
            ))}
          </BarChart>
        )}
      </ResponsiveContainer>
    </div>
  );
};

export default ChartRenderer;