
import React, { useState, useMemo, useCallback, ChangeEvent } from 'react';
import { CompoundingFrequency } from '../types';
import type { InputProps, SelectProps, ButtonProps, CardProps, ChartDataPoint, CompoundInterestInput, CompoundInterestResult, ComparisonScenario, MortgageDetails, InvestmentDetails, MortgageVsInvestingResult, FIInput, FIResult } from '../types';
import { DEFAULT_CURRENCY, DEFAULT_PERCENTAGE_SIGN, COMPOUNDING_FREQUENCY_OPTIONS, CONTRIBUTION_FREQUENCY_OPTIONS } from '../constants';
import { calculateCompoundInterest, calculateMortgageVsInvesting, calculateFinancialIndependence, formatCurrency } from '../services/financialFormulas';
import ChartRenderer from '../components/ChartRenderer.tsx';

// Reusable UI Components

const InputComponent: React.FC<InputProps> = ({ label, id, unit, info, ...props }) => (
  <div className="mb-5">
    <label htmlFor={id} className="block text-sm font-medium text-slate-200 mb-1.5">
      {label} {info && <span className="text-xs text-slate-400 italic ml-1">( {info} )</span>}
    </label>
    <div className="relative">
      <input
        id={id}
        className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg shadow-sm text-slate-100 placeholder-slate-400 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500 focus:ring-opacity-50 transition-colors duration-150 ease-in-out"
        {...props}
      />
      {unit && <span className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-sm text-slate-400">{unit}</span>}
    </div>
  </div>
);

const SelectComponent: React.FC<SelectProps> = ({ label, id, options, info, ...props }) => (
  <div className="mb-5">
    <label htmlFor={id} className="block text-sm font-medium text-slate-200 mb-1.5">
      {label} {info && <span className="text-xs text-slate-400 italic ml-1">( {info} )</span>}
    </label>
    <select
      id={id}
      className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg shadow-sm text-slate-100 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500 focus:ring-opacity-50 transition-colors duration-150 ease-in-out"
      {...props}
    >
      {options.map(option => (
        <option key={option.value} value={option.value} className="bg-slate-700 text-slate-100">{option.label}</option>
      ))}
    </select>
  </div>
);

const ButtonComponent: React.FC<ButtonProps> = ({ children, onClick, type = "button", variant = 'primary', className = '', disabled }) => {
  const baseStyle = "px-6 py-3 rounded-lg font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 transition ease-in-out duration-150";
  const styles = {
    primary: 'bg-emerald-600 hover:bg-emerald-700 focus:ring-emerald-500 text-white',
    secondary: 'bg-slate-600 hover:bg-slate-700 focus:ring-slate-500 text-slate-100',
    danger: 'bg-red-600 hover:bg-red-700 focus:ring-red-500 text-white',
  };
  return (
    <button type={type} onClick={onClick} className={`${baseStyle} ${styles[variant]} ${disabled ? 'opacity-60 cursor-not-allowed' : 'hover:scale-[1.02] active:scale-[0.98]'} ${className}`} disabled={disabled}>
      {children}
    </button>
  );
};

const CardComponent: React.FC<CardProps> = ({ title, children, className = '' }) => (
  <div className={`bg-slate-800 shadow-xl rounded-lg p-6 ${className}`}>
    {title && <h2 className="text-2xl font-semibold text-emerald-400 mb-6 border-b border-slate-700 pb-4">{title}</h2>}
    {children}
  </div>
);

const ResultsDisplay: React.FC<{ results: Record<string, string | number | ChartDataPoint[] | undefined | { name?: string; [key: string]: any} > | null, titleOverride?: string }> = ({ results, titleOverride }) => {
  if (!results) return null;
  
  const displayTitle = titleOverride || (typeof results.title === 'string' ? results.title : "Results");
  
  return (
    <CardComponent title={displayTitle} className="mt-6">
      <dl className="space-y-1">
        {Object.entries(results).map(([key, value]) => {
          if (key === 'title' || typeof value === 'undefined' || Array.isArray(value) || (typeof value === 'object' && value !== null && !React.isValidElement(value))) return null; 
          
          const formattedKey = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
          const displayValue = typeof value === 'number' 
            ? (key.toLowerCase().includes('year') || key.toLowerCase().includes('age') || key.toLowerCase().includes('period') ? value.toFixed(key.toLowerCase().includes('year') && value < 5 && value !==0 ? 1:0) : formatCurrency(value)) 
            : String(value);
            
          return (
            <div key={key} className="flex justify-between items-center py-3 border-b border-slate-700/70 last:border-b-0 text-base">
              <dt className="text-slate-400">{formattedKey}</dt>
              <dd className="text-slate-50 font-semibold text-right">{displayValue}</dd>
            </div>
          );
        })}
      </dl>
    </CardComponent>
  );
};


// Calculators

export const CompoundInterestCalculator: React.FC = () => {
  const [inputs, setInputs] = useState<CompoundInterestInput>({
    initialPrincipal: 10000,
    annualInterestRate: 5,
    investmentPeriodYears: 10,
    compoundingFrequency: CompoundingFrequency.Annually,
    regularContribution: 100,
    contributionFrequency: CompoundingFrequency.Monthly,
    contributionAtBeginning: false,
  });
  const [results, setResults] = useState<CompoundInterestResult | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const isCheckbox = type === 'checkbox';
    const val = isCheckbox 
        ? (e.target as HTMLInputElement).checked 
        : (type === 'number' || e.target.tagName === 'SELECT') ? parseFloat(value) : value;

    setInputs(prev => ({ ...prev, [name]: val as any }));
  };
  

  const handleSubmit = useCallback(() => {
    const calcResults = calculateCompoundInterest(inputs);
    setResults(calcResults);
  }, [inputs]);

   React.useEffect(() => {
    handleSubmit();
   }, [handleSubmit]); // Added handleSubmit to dependency array as it's stable due to useCallback


  return (
    <CardComponent title="Compound Interest Calculator">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
        <InputComponent label="Initial Principal" id="initialPrincipal" name="initialPrincipal" type="number" value={inputs.initialPrincipal} onChange={handleChange} unit={DEFAULT_CURRENCY} min="0" />
        <InputComponent label="Annual Interest Rate" id="annualInterestRate" name="annualInterestRate" type="number" value={inputs.annualInterestRate} onChange={handleChange} unit={DEFAULT_PERCENTAGE_SIGN} min="0" step="0.1" />
        <InputComponent label="Investment Period" id="investmentPeriodYears" name="investmentPeriodYears" type="number" value={inputs.investmentPeriodYears} onChange={handleChange} unit="Years" min="1" />
        <SelectComponent label="Compounding Frequency" id="compoundingFrequency" name="compoundingFrequency" value={String(inputs.compoundingFrequency)} onChange={handleChange} options={COMPOUNDING_FREQUENCY_OPTIONS} />
        <InputComponent label="Regular Contribution" id="regularContribution" name="regularContribution" type="number" value={inputs.regularContribution} onChange={handleChange} unit={DEFAULT_CURRENCY} min="0" info={`per ${COMPOUNDING_FREQUENCY_OPTIONS.find(o => o.value === String(inputs.compoundingFrequency))?.label.toLowerCase().replace('-ly','').slice(0,-1) || 'period'}`} />
        <SelectComponent label="Contribution Frequency" id="contributionFrequency" name="contributionFrequency" value={String(inputs.contributionFrequency)} onChange={handleChange} options={CONTRIBUTION_FREQUENCY_OPTIONS} info="Usually matches compounding frequency"/>
         <div className="md:col-span-2 flex items-center my-4">
            <input type="checkbox" id="contributionAtBeginning" name="contributionAtBeginning" checked={inputs.contributionAtBeginning} onChange={handleChange} className="form-checkbox h-5 w-5 text-emerald-600 bg-slate-600 border-slate-500 rounded focus:ring-emerald-500 focus:ring-offset-slate-800 focus:ring-2 cursor-pointer" />
            <label htmlFor="contributionAtBeginning" className="ml-3 text-sm text-slate-200 cursor-pointer">Make contributions at the beginning of each period</label>
        </div>
      </div>
       {results && (
        <>
          <ResultsDisplay results={{ futureValue: results.futureValue, totalPrincipal: results.totalPrincipal, totalInterest: results.totalInterest }} />
          <div className="mt-8 h-96 md:h-[450px]">
             <ChartRenderer 
                data={results.breakdown} 
                type="line" 
                xDataKey="name" 
                yDataKeys={[{ key: 'Value', color: '#10b981', name: 'Portfolio Value'}]}
                title="Investment Growth Over Time"
                yAxisLabel="Value"
                xAxisLabel="Year"
             />
          </div>
        </>
      )}
    </CardComponent>
  );
};


export const CompoundInterestComparisonCalculator: React.FC = () => {
  const initialScenarioState: ComparisonScenario = {
    initialPrincipal: 10000, annualInterestRate: 5, investmentPeriodYears: 10,
    compoundingFrequency: CompoundingFrequency.Annually, regularContribution: 100,
    contributionFrequency: CompoundingFrequency.Monthly, contributionAtBeginning: false, annualCharges: 0
  };
  const [scenario1, setScenario1] = useState<ComparisonScenario>(initialScenarioState);
  const [scenario2, setScenario2] = useState<ComparisonScenario>({...initialScenarioState, annualInterestRate: 6, annualCharges: 0.5 });
  const [results1, setResults1] = useState<CompoundInterestResult | null>(null);
  const [results2, setResults2] = useState<CompoundInterestResult | null>(null);

  const handleScenarioChange = (setter: React.Dispatch<React.SetStateAction<ComparisonScenario>>) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const isCheckbox = type === 'checkbox';
    const val = isCheckbox 
      ? (e.target as HTMLInputElement).checked 
      : (type === 'number' || e.target.tagName === 'SELECT') ? parseFloat(value) : value;
    setter(prev => ({ ...prev, [name]: val as any }));
  };
  
  const calculateAll = useCallback(() => {
    setResults1(calculateCompoundInterest(scenario1, scenario1.annualCharges));
    setResults2(calculateCompoundInterest(scenario2, scenario2.annualCharges));
  }, [scenario1, scenario2]);

  React.useEffect(() => {
    calculateAll();
  }, [calculateAll]);
  
  const chartData = useMemo(() => {
    if (!results1 || !results2) return [];
    const maxLength = Math.max(results1.breakdown.length, results2.breakdown.length);
    const data: ChartDataPoint[] = [];
    for (let i = 0; i < maxLength; i++) {
      data.push({
        name: results1.breakdown[i]?.name || results2.breakdown[i]?.name || `Year ${i}`,
        Scenario1: results1.breakdown[i]?.Value as number || 0,
        Scenario2: results2.breakdown[i]?.Value as number || 0,
      });
    }
    return data;
  }, [results1, results2]);

  const renderScenarioInputs = (scenario: ComparisonScenario, handler: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void, idPrefix: string) => (
    <>
      <InputComponent label="Initial Principal" id={`${idPrefix}InitialPrincipal`} name="initialPrincipal" type="number" value={scenario.initialPrincipal} onChange={handler} unit={DEFAULT_CURRENCY} min="0" />
      <InputComponent label="Annual Interest Rate" id={`${idPrefix}AnnualInterestRate`} name="annualInterestRate" type="number" value={scenario.annualInterestRate} onChange={handler} unit={DEFAULT_PERCENTAGE_SIGN} min="0" step="0.1" />
      <InputComponent label="Investment Period (Years)" id={`${idPrefix}InvestmentPeriodYears`} name="investmentPeriodYears" type="number" value={scenario.investmentPeriodYears} onChange={handler} unit="Years" min="1" />
      <SelectComponent label="Compounding Frequency" id={`${idPrefix}CompoundingFrequency`} name="compoundingFrequency" value={String(scenario.compoundingFrequency)} onChange={handler} options={COMPOUNDING_FREQUENCY_OPTIONS} />
      <InputComponent label="Regular Contribution" id={`${idPrefix}RegularContribution`} name="regularContribution" type="number" value={scenario.regularContribution} onChange={handler} unit={DEFAULT_CURRENCY} min="0" info={`per ${COMPOUNDING_FREQUENCY_OPTIONS.find(o => o.value === String(scenario.compoundingFrequency))?.label.toLowerCase().replace('-ly','').slice(0,-1) || 'period'}`} />
      <SelectComponent label="Contribution Frequency" id={`${idPrefix}ContributionFrequency`} name="contributionFrequency" value={String(scenario.contributionFrequency)} onChange={handler} options={CONTRIBUTION_FREQUENCY_OPTIONS} />
      <InputComponent label="Annual Charges" id={`${idPrefix}AnnualCharges`} name="annualCharges" type="number" value={scenario.annualCharges} onChange={handler} unit={DEFAULT_PERCENTAGE_SIGN} info="Deducted from returns" min="0" step="0.01"/>
       <div className="flex items-center my-4">
          <input type="checkbox" id={`${idPrefix}ContributionAtBeginning`} name="contributionAtBeginning" checked={scenario.contributionAtBeginning} onChange={handler} className="form-checkbox h-5 w-5 text-emerald-600 bg-slate-600 border-slate-500 rounded focus:ring-emerald-500 focus:ring-offset-slate-850 focus:ring-2 cursor-pointer" />
          <label htmlFor={`${idPrefix}ContributionAtBeginning`} className="ml-3 text-sm text-slate-200 cursor-pointer">Contributions at period start</label>
      </div>
    </>
  );

  return (
    <CardComponent title="Compound Interest Comparison">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <CardComponent title="Scenario 1" className="bg-slate-850/80 !p-5 rounded-xl"> {/* Slightly different bg for nested cards */}
          {renderScenarioInputs(scenario1, handleScenarioChange(setScenario1), 's1')}
        </CardComponent>
        <CardComponent title="Scenario 2" className="bg-slate-850/80 !p-5 rounded-xl">
          {renderScenarioInputs(scenario2, handleScenarioChange(setScenario2), 's2')}
        </CardComponent>
      </div>
      
      {results1 && results2 && (
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-4 text-emerald-300">Comparison Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <ResultsDisplay results={{ scenario1FutureValue: results1.futureValue, scenario1TotalInterest: results1.totalInterest }} titleOverride="Scenario 1 Results" />
            <ResultsDisplay results={{ scenario2FutureValue: results2.futureValue, scenario2TotalInterest: results2.totalInterest }} titleOverride="Scenario 2 Results" />
          </div>
          <div className="mt-8 h-96 md:h-[450px]">
            <ChartRenderer 
                data={chartData} 
                type="line" 
                xDataKey="name" 
                yDataKeys={[
                { key: 'Scenario1', color: '#34d399', name: 'Scenario 1 Value' },
                { key: 'Scenario2', color: '#fbbf24', name: 'Scenario 2 Value' }
                ]}
                title="Investment Growth Comparison"
                yAxisLabel="Value"
                xAxisLabel="Year"
            />
          </div>
        </div>
      )}
    </CardComponent>
  );
};

export const MortgageVsInvestingCalculator: React.FC = () => {
  const [mortgageDetails, setMortgageDetails] = useState<MortgageDetails>({
    principal: 250000, annualInterestRate: 3.5, termYears: 25, monthlyOverpayment: 200
  });
  const [investmentDetails, setInvestmentDetails] = useState<InvestmentDetails>({ annualReturnRate: 6 });
  const [results, setResults] = useState<MortgageVsInvestingResult | null>(null);

  const handleChange = (setter: React.Dispatch<React.SetStateAction<any>>) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setter((prev: any) => ({ ...prev, [name]: parseFloat(value) || 0 }));
  };

  const handleSubmit = useCallback(() => {
    if (mortgageDetails.principal >= 0 && mortgageDetails.annualInterestRate >= 0 && mortgageDetails.termYears > 0 && investmentDetails.annualReturnRate >= 0) {
      const calcResults = calculateMortgageVsInvesting(mortgageDetails, investmentDetails);
      setResults(calcResults);
    } else {
      setResults(null); 
    }
  }, [mortgageDetails, investmentDetails]);

  React.useEffect(() => {
    handleSubmit();
  }, [handleSubmit]);

  return (
    <CardComponent title="Mortgage Overpayment vs. Investing">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <CardComponent title="Mortgage Details" className="bg-slate-850/80 !p-5 rounded-xl">
          <InputComponent label="Mortgage Principal" id="mortgagePrincipal" name="principal" type="number" value={mortgageDetails.principal} onChange={handleChange(setMortgageDetails)} unit={DEFAULT_CURRENCY} min="0"/>
          <InputComponent label="Annual Interest Rate" id="mortgageAnnualInterestRate" name="annualInterestRate" type="number" value={mortgageDetails.annualInterestRate} onChange={handleChange(setMortgageDetails)} unit={DEFAULT_PERCENTAGE_SIGN} min="0" step="0.01"/>
          <InputComponent label="Mortgage Term" id="mortgageTermYears" name="termYears" type="number" value={mortgageDetails.termYears} onChange={handleChange(setMortgageDetails)} unit="Years" min="1"/>
          <InputComponent label="Monthly Overpayment" id="monthlyOverpayment" name="monthlyOverpayment" type="number" value={mortgageDetails.monthlyOverpayment} onChange={handleChange(setMortgageDetails)} unit={DEFAULT_CURRENCY} min="0"/>
        </CardComponent>
        <CardComponent title="Investment Details" className="bg-slate-850/80 !p-5 rounded-xl">
          <InputComponent label="Expected Annual Investment Return" id="annualReturnRate" name="annualReturnRate" type="number" value={investmentDetails.annualReturnRate} onChange={handleChange(setInvestmentDetails)} unit={DEFAULT_PERCENTAGE_SIGN} info="For the overpayment amount" min="0" step="0.1"/>
        </CardComponent>
      </div>

      {results && (
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-4 text-emerald-300">Comparison Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <ResultsDisplay titleOverride="Overpayment Scenario" results={{ 
              yearsToPayOff: results.overpaymentScenario.yearsToPayOff,
              totalInterestPaid: results.overpaymentScenario.totalInterestPaid,
              interestSaved: results.overpaymentScenario.interestSaved,
            }} />
            <ResultsDisplay titleOverride="Investing Scenario" results={{
              mortgageTotalInterestPaid: results.investingScenario.mortgageTotalInterestPaid,
              investmentValueAtMortgageEnd: results.investingScenario.investmentValueAtMortgageEnd,
              netBenefitOfInvesting: results.investingScenario.netBenefitOfInvesting,
            }} />
          </div>
           {results.comparisonChartData && results.comparisonChartData.length > 0 && (
            <div className="mt-8 h-96 md:h-[450px]">
                <ChartRenderer 
                    data={results.comparisonChartData} 
                    type="bar" 
                    xDataKey="name" 
                    yDataKeys={[
                    { key: 'Overpayment', color: '#34d399', name: 'Outcome with Overpayment' }, 
                    { key: 'Standard Mortgage', color: '#fbbf24', name: 'Outcome with Investing' } 
                    ]}
                    title="Financial Outcome Comparison"
                    yAxisLabel="Amount"
                />
            </div>
           )}
           <div className="mt-8 p-4 bg-slate-850/80 rounded-lg text-slate-300 text-sm">
            <p className="font-semibold text-emerald-400 mb-1">Understanding "Net Benefit of Investing":</p>
            <p>A positive value suggests that investing the extra cash (instead of overpaying the mortgage) could lead to a better overall financial position by the end of the original mortgage term. A negative value indicates that overpaying the mortgage might be more financially advantageous.</p>
            <p className="mt-2">This comparison is simplified and assumes factors like tax implications on investments are not included. House equity is considered in terms of loan reduction.</p>
          </div>
        </div>
      )}
    </CardComponent>
  );
};


export const FinancialIndependenceCalculator: React.FC = () => {
  const [inputs, setInputs] = useState<FIInput>({
    currentAge: 30, desiredRetirementAge: 60, currentSavings: 10000, currentPortfolio: 50000,
    preRetirementAnnualReturnRate: 7, postRetirementAnnualReturnRate: 5, 
    desiredAnnualSpending: 40000, expectedInflationRate: 2.5, safeWithdrawalRate: 4
  });
  const [results, setResults] = useState<FIResult | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
  };

  const handleSubmit = useCallback(() => {
    const calcResults = calculateFinancialIndependence(inputs);
    setResults(calcResults);
  }, [inputs]);

  React.useEffect(() => {
    handleSubmit();
  }, [handleSubmit]);

  return (
    <CardComponent title="Financial Independence (FI) Calculator">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
        <InputComponent label="Current Age" id="currentAge" name="currentAge" type="number" value={inputs.currentAge} onChange={handleChange} unit="Years" min="0"/>
        <InputComponent label="Desired Retirement Age" id="desiredRetirementAge" name="desiredRetirementAge" type="number" value={inputs.desiredRetirementAge} onChange={handleChange} unit="Years" min="0"/>
        <InputComponent label="Current Annual Savings" id="currentSavings" name="currentSavings" type="number" value={inputs.currentSavings} onChange={handleChange} unit={DEFAULT_CURRENCY} min="0"/>
        <InputComponent label="Current Investment Portfolio" id="currentPortfolio" name="currentPortfolio" type="number" value={inputs.currentPortfolio} onChange={handleChange} unit={DEFAULT_CURRENCY} min="0"/>
        <InputComponent label="Pre-Retirement Annual Return Rate" id="preRetirementAnnualReturnRate" name="preRetirementAnnualReturnRate" type="number" value={inputs.preRetirementAnnualReturnRate} onChange={handleChange} unit={DEFAULT_PERCENTAGE_SIGN} min="0" step="0.1" info="Avg. annual growth"/>
        <InputComponent label="Desired Annual Spending (Today's Money)" id="desiredAnnualSpending" name="desiredAnnualSpending" type="number" value={inputs.desiredAnnualSpending} onChange={handleChange} unit={DEFAULT_CURRENCY} min="0" info="In current value"/>
        <InputComponent label="Expected Annual Inflation Rate" id="expectedInflationRate" name="expectedInflationRate" type="number" value={inputs.expectedInflationRate} onChange={handleChange} unit={DEFAULT_PERCENTAGE_SIGN} min="0" step="0.1" info="Avg. annual inflation"/>
        <InputComponent label="Safe Withdrawal Rate (SWR)" id="safeWithdrawalRate" name="safeWithdrawalRate" type="number" value={inputs.safeWithdrawalRate} onChange={handleChange} unit={DEFAULT_PERCENTAGE_SIGN} info="e.g., 4 for 4%" min="0.1" step="0.1"/>
      </div>

      {results && (
        <>
          <ResultsDisplay results={{ 
            fiNumberTarget: results.fiNumber, 
            yearsToFI: results.yearsToFI, 
            ageAtFI: results.ageAtFI,
            projectedPortfolioAtRetirement: results.projectedPortfolioAtRetirement
          }} />
          {results.portfolioGrowthChart && results.portfolioGrowthChart.length > 0 && (
            <div className="mt-8 h-96 md:h-[450px]">
                <ChartRenderer 
                data={results.portfolioGrowthChart} 
                type="line" 
                xDataKey="name" 
                yDataKeys={[
                    { key: 'Portfolio', color: '#34d399', name: 'Projected Portfolio' },
                    { key: 'FI Target', color: '#fbbf24', name: 'FI Target (Inflated)' }
                ]}
                title="Path to Financial Independence"
                yAxisLabel="Value"
                xAxisLabel="Age"
                />
            </div>
          )}
        </>
      )}
    </CardComponent>
  );
};
