
import type { ReactNode } from 'react';

export interface Tab {
  id: string;
  label: string;
}

export enum CompoundingFrequency {
  Annually = 1,
  SemiAnnually = 2,
  Quarterly = 4,
  Monthly = 12,
  Daily = 365,
}

export interface InputProps {
  label: string;
  id: string;
  name: string; // Added name property
  type: string;
  value: string | number;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  unit?: string;
  min?: string;
  max?: string;
  step?: string;
  info?: string;
}

export interface SelectProps {
  label: string;
  id: string;
  name: string; // Added name property
  value: string | number;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: { value: string | number; label: string }[];
  info?: string;
}

export interface ButtonProps {
  onClick?: () => void;
  children: ReactNode;
  type?: "button" | "submit" | "reset";
  variant?: 'primary' | 'secondary' | 'danger';
  className?: string;
  disabled?: boolean;
}

export interface CardProps {
  title?: string;
  children: ReactNode;
  className?: string;
}

export interface ChartDataPoint {
  name: string | number;
  [key: string]: number | string; // Allows for multiple lines/bars, e.g., value1, value2
}

// Compound Interest Calculator
export interface CompoundInterestInput {
  initialPrincipal: number;
  annualInterestRate: number;
  investmentPeriodYears: number;
  compoundingFrequency: CompoundingFrequency;
  regularContribution: number;
  contributionFrequency: CompoundingFrequency; // Can be different from compounding freq
  contributionAtBeginning: boolean; // True if contribution at beginning of period, false if at end
}

export interface CompoundInterestResult {
  futureValue: number;
  totalPrincipal: number;
  totalInterest: number;
  breakdown: ChartDataPoint[];
}

// Compound Interest Comparison Calculator
export interface ComparisonScenario extends CompoundInterestInput {
  annualCharges: number; // Percentage
}

// Mortgage vs Investing Calculator
export interface MortgageDetails {
  principal: number;
  annualInterestRate: number;
  termYears: number;
  monthlyOverpayment: number;
}

export interface InvestmentDetails {
  annualReturnRate: number;
}

export interface MortgageVsInvestingResult {
  overpaymentScenario: {
    yearsToPayOff: number;
    totalInterestPaid: number;
    totalPaid: number;
    interestSaved: number;
  };
  investingScenario: {
    mortgageTotalInterestPaid: number; // If not overpaying
    mortgageTotalPaid: number; // If not overpaying
    investmentValueAtMortgageEnd: number;
    netBenefitOfInvesting: number; // Compares final financial position
  };
  comparisonChartData: ChartDataPoint[];
}

// Financial Independence Calculator
export interface FIInput {
  currentAge: number;
  desiredRetirementAge: number;
  currentSavings: number; // annual savings
  currentPortfolio: number;
  preRetirementAnnualReturnRate: number;
  postRetirementAnnualReturnRate: number; // For SWR stability, less used in simple FI calc
  desiredAnnualSpending: number; // In today's money
  expectedInflationRate: number;
  safeWithdrawalRate: number; // e.g. 0.04 for 4%
}

export interface FIResult {
  fiNumber: number;
  yearsToFI: number | string; // Can be "Already FI" or "Never Reaches"
  ageAtFI: number | string;
  projectedPortfolioAtRetirement: number;
  portfolioGrowthChart: ChartDataPoint[];
}
