
import type { Tab } from './types';

export const CALCULATOR_TABS: Tab[] = [
  { id: 'compoundInterest', label: 'Compound Interest' },
  { id: 'compoundInterestComparison', label: 'Compare Compound Interest' },
  { id: 'mortgageVsInvesting', label: 'Mortgage Overpayment vs. Investing' },
  { id: 'financialIndependence', label: 'Financial Independence (FI)' },
];

export const DEFAULT_CURRENCY = '$';
export const DEFAULT_PERCENTAGE_SIGN = '%';

export const COMPOUNDING_FREQUENCY_OPTIONS = [
  { value: "1", label: 'Annually' },
  { value: "2", label: 'Semi-Annually' },
  { value: "4", label: 'Quarterly' },
  { value: "12", label: 'Monthly' },
  { value: "365", label: 'Daily' },
];

export const CONTRIBUTION_FREQUENCY_OPTIONS = COMPOUNDING_FREQUENCY_OPTIONS; // Often the same
