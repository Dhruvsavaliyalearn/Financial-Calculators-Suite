
import type { CompoundingFrequency, CompoundInterestInput, CompoundInterestResult, ComparisonScenario, MortgageDetails, InvestmentDetails, MortgageVsInvestingResult, FIInput, FIResult, ChartDataPoint } from '../types';

export const calculateCompoundInterest = (inputs: CompoundInterestInput, annualChargesRate: number = 0): CompoundInterestResult => {
  const { initialPrincipal, annualInterestRate, investmentPeriodYears, compoundingFrequency, regularContribution, contributionFrequency, contributionAtBeginning } = inputs;

  const rAnnual = annualInterestRate / 100;
  const RCharges = annualChargesRate / 100;
  let P = initialPrincipal;
  let totalPrincipalInvested = initialPrincipal;
  const breakdown: ChartDataPoint[] = [{ name: 'Year 0', Value: P }];
  
  const periodsPerYear = compoundingFrequency as number;
  const contributionPeriodsPerYear = contributionFrequency as number; // How many times contribution is made in a year
  // const contributionAmountPerPeriod = regularContribution / (contributionPeriodsPerYear / periodsPerYear); // Distribute annual contribution over compounding periods if frequencies differ, or use directly if same. This logic might need refinement if contribution freq is not a multiple of compounding freq. Simpler if they are aligned or contribution is annual. Let's assume contribution is per compounding period for now.
  
  // If contribution frequency matches compounding frequency:
  const pmt = regularContribution; // This is the contribution per compounding period
  const nCompound = periodsPerYear; // Compounding periods per year
  const rCompound = rAnnual / nCompound; // Interest rate per compounding period

  let currentBalance = P;
  
  for (let year = 1; year <= investmentPeriodYears; year++) {
    // let yearStartBalance = currentBalance;
    for (let period = 1; period <= nCompound; period++) {
      if (pmt > 0 && contributionAtBeginning) {
        currentBalance += pmt;
        // if(period === 1) totalPrincipalInvested += pmt * nCompound; // Simplified: add annual contribution. This was causing issues with totalPrincipal.
      }
      currentBalance *= (1 + rCompound);
      if (pmt > 0 && !contributionAtBeginning) {
        currentBalance += pmt;
        // if(period === nCompound && !contributionAtBeginning) totalPrincipalInvested += pmt * nCompound; // Simplified: add annual contribution. This was causing issues.
      }
    }
    // Apply annual charges at the end of the year
    if (RCharges > 0) {
      currentBalance *= (1 - RCharges);
    }
    breakdown.push({ name: `Year ${year}`, Value: parseFloat(currentBalance.toFixed(2)) });
  }
  
  // Calculate total principal invested more accurately
  totalPrincipalInvested = initialPrincipal;
  if (regularContribution > 0 && investmentPeriodYears > 0) {
    // This assumes `regularContribution` is the amount per contribution period, and `contributionFrequency` is the number of times per year.
    // The loop adds `pmt` (which is `regularContribution`) `nCompound` (compoundingFrequency) times per year.
    // So, if contributionFrequency aligns with compoundingFrequency, this is correct.
    // Let's assume `regularContribution` is the amount added each time according to `compoundingFrequency`.
    totalPrincipalInvested += regularContribution * compoundingFrequency * investmentPeriodYears;
  }


  const futureValue = parseFloat(currentBalance.toFixed(2));
  const totalInterest = parseFloat((futureValue - totalPrincipalInvested).toFixed(2));

  return { futureValue, totalPrincipal: parseFloat(totalPrincipalInvested.toFixed(2)), totalInterest, breakdown };
};


export const calculateMortgagePayment = (principal: number, annualInterestRate: number, termYears: number): number => {
  if (principal <= 0 || annualInterestRate < 0 || termYears <= 0) return principal > 0 && termYears > 0 ? principal / (termYears * 12) : 0; // Handle 0 interest rate
  if (annualInterestRate === 0) return principal / (termYears * 12);

  const monthlyInterestRate = annualInterestRate / 100 / 12;
  const numberOfPayments = termYears * 12;
  
  const payment = principal * (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments)) / (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1);
  return payment;
};

export const calculateMortgageVsInvesting = (mortgage: MortgageDetails, investment: InvestmentDetails): MortgageVsInvestingResult => {
  const monthlyMortgageRate = mortgage.annualInterestRate / 100 / 12;
  const originalTermMonths = mortgage.termYears * 12;

  // Scenario 1: Overpayment
  let remainingBalanceOverpayment = mortgage.principal;
  let monthsToPayOffOverpayment = 0;
  let totalInterestPaidOverpayment = 0;
  const standardMonthlyPayment = calculateMortgagePayment(mortgage.principal, mortgage.annualInterestRate, mortgage.termYears);
  
  if (standardMonthlyPayment === Infinity || standardMonthlyPayment <=0 && mortgage.principal > 0 ) { // Edge case for invalid mortgage params leading to bad payment calc
    // Return a default or error indicating structure
    return {
      overpaymentScenario: { yearsToPayOff: 0, totalInterestPaid: 0, totalPaid: 0, interestSaved: 0 },
      investingScenario: { mortgageTotalInterestPaid: 0, mortgageTotalPaid: 0, investmentValueAtMortgageEnd: 0, netBenefitOfInvesting: 0 },
      comparisonChartData: []
    } as MortgageVsInvestingResult;
  }

  const actualMonthlyPayment = standardMonthlyPayment + mortgage.monthlyOverpayment;

  if (actualMonthlyPayment <=0 && mortgage.principal > 0) { 
     return {
      overpaymentScenario: { yearsToPayOff: Infinity, totalInterestPaid: Infinity, totalPaid: Infinity, interestSaved: 0 },
      investingScenario: { 
        mortgageTotalInterestPaid: standardMonthlyPayment > 0 ? (standardMonthlyPayment * originalTermMonths - mortgage.principal) : Infinity, 
        mortgageTotalPaid: standardMonthlyPayment > 0 ? standardMonthlyPayment * originalTermMonths : Infinity, 
        investmentValueAtMortgageEnd: 0, 
        netBenefitOfInvesting: 0 
      },
      comparisonChartData: []
    } as MortgageVsInvestingResult;
  }
  
  if (mortgage.principal > 0) {
    while (remainingBalanceOverpayment > 0 && monthsToPayOffOverpayment < originalTermMonths * 2) { // Safety break
      const interestThisMonth = remainingBalanceOverpayment * monthlyMortgageRate;
      totalInterestPaidOverpayment += interestThisMonth;
      const principalPaid = actualMonthlyPayment - interestThisMonth;
      if (principalPaid <= 0 && monthlyMortgageRate > 0) { // Interest is higher than payment, will never pay off
         monthsToPayOffOverpayment = Infinity;
         totalInterestPaidOverpayment = Infinity;
         break;
      }
      remainingBalanceOverpayment -= principalPaid;
      monthsToPayOffOverpayment++;
      if (remainingBalanceOverpayment <= 0.005) { // Paid off (handle small remainders)
        remainingBalanceOverpayment = 0; 
      }
    }
  } else { // No principal
    monthsToPayOffOverpayment = 0;
    totalInterestPaidOverpayment = 0;
  }

  const yearsToPayOffOverpayment = isFinite(monthsToPayOffOverpayment) ? monthsToPayOffOverpayment / 12 : Infinity;
  const totalPaidOverpaymentValue = isFinite(totalInterestPaidOverpayment) ? mortgage.principal + totalInterestPaidOverpayment : Infinity;


  // Scenario 2: Standard Mortgage Payment + Investing the Overpayment Amount
  let totalInterestPaidStandard = 0;
  let currentBalanceStandard = mortgage.principal;
  if (mortgage.principal > 0 && standardMonthlyPayment > 0) {
    for (let i = 0; i < originalTermMonths; i++) {
      const interest = currentBalanceStandard * monthlyMortgageRate;
      totalInterestPaidStandard += interest;
      currentBalanceStandard -= (standardMonthlyPayment - interest);
       if (currentBalanceStandard <= 0.005) {
        currentBalanceStandard = 0;
        totalInterestPaidStandard = standardMonthlyPayment * (i + 1) - mortgage.principal; // More accurate total interest
        break;
      }
    }
     if (currentBalanceStandard > 0.005 && standardMonthlyPayment * monthlyMortgageRate >= standardMonthlyPayment) { // Will not pay off
      totalInterestPaidStandard = Infinity;
    }
  } else if (mortgage.principal === 0) {
    totalInterestPaidStandard = 0;
  } else { // standardMonthlyPayment <= 0 but principal > 0
    totalInterestPaidStandard = Infinity;
  }


  let investmentValue = 0;
  const monthlyInvestmentReturnRate = (investment.annualReturnRate / 100) / 12;
  if (mortgage.monthlyOverpayment > 0 && isFinite(originalTermMonths)) {
    for (let i = 0; i < originalTermMonths; i++) {
      investmentValue = (investmentValue + mortgage.monthlyOverpayment) * (1 + monthlyInvestmentReturnRate);
    }
  }
  
  const mortgageTotalPaidStandard = isFinite(totalInterestPaidStandard) ? mortgage.principal + totalInterestPaidStandard : Infinity;
  
  const interestSavedByOverpayment = isFinite(totalInterestPaidStandard) && isFinite(totalInterestPaidOverpayment) ? totalInterestPaidStandard - totalInterestPaidOverpayment : 0;
  
  const netBenefitOfInvesting = isFinite(investmentValue) && isFinite(interestSavedByOverpayment) ? investmentValue - interestSavedByOverpayment : -interestSavedByOverpayment;


  return {
    overpaymentScenario: {
      yearsToPayOff: parseFloat(yearsToPayOffOverpayment.toFixed(2)),
      totalInterestPaid: parseFloat(totalInterestPaidOverpayment.toFixed(2)),
      totalPaid: parseFloat(totalPaidOverpaymentValue.toFixed(2)),
      interestSaved: parseFloat(interestSavedByOverpayment.toFixed(2)),
    },
    investingScenario: {
      mortgageTotalInterestPaid: parseFloat(totalInterestPaidStandard.toFixed(2)),
      mortgageTotalPaid: parseFloat(mortgageTotalPaidStandard.toFixed(2)),
      investmentValueAtMortgageEnd: parseFloat(investmentValue.toFixed(2)),
      netBenefitOfInvesting: parseFloat(netBenefitOfInvesting.toFixed(2))
    },
    comparisonChartData: [
      { name: 'Interest Paid', Overpayment: parseFloat(totalInterestPaidOverpayment.toFixed(2)), 'Standard Mortgage': parseFloat(totalInterestPaidStandard.toFixed(2)) },
      { name: 'Investment Value', Overpayment: 0, 'Standard Mortgage': parseFloat(investmentValue.toFixed(2)) },
    ]
  };
};


export const calculateFinancialIndependence = (inputs: FIInput): FIResult => {
  const { currentAge, desiredRetirementAge, currentSavings, currentPortfolio, preRetirementAnnualReturnRate, desiredAnnualSpending, expectedInflationRate, safeWithdrawalRate } = inputs;

  if (safeWithdrawalRate <= 0) { // Avoid division by zero
    return {
      fiNumber: Infinity,
      yearsToFI: "SWR must be > 0",
      ageAtFI: "SWR must be > 0",
      projectedPortfolioAtRetirement: currentPortfolio,
      portfolioGrowthChart: [{ name: currentAge, Portfolio: currentPortfolio, 'FI Target': Infinity }],
    };
  }

  const rPreRetirement = preRetirementAnnualReturnRate / 100;
  const inflation = expectedInflationRate / 100;
  const swr = safeWithdrawalRate / 100;

  const portfolioGrowthChart: ChartDataPoint[] = [{ name: currentAge, Portfolio: currentPortfolio, 'FI Target': desiredAnnualSpending / swr }];
  
  let fiNumberTarget = desiredAnnualSpending / swr; // Initial FI number based on today's spending
  let projectedPortfolio = currentPortfolio;
  let yearsToFI: number | string = "Not Calculated";
  let ageAtFI: number | string = "Not Calculated";
  let foundFI = false;

  const maxYears = Math.max(desiredRetirementAge - currentAge, 0) + 30; // Project for at least 30 years beyond desired retirement if not FI or current age

  for (let year = 1; year <= maxYears; year++) {
    const age = currentAge + year;
    // Adjust FI target for inflation for current year's end (applies to spending next year)
    const inflatedSpendingThisYear = desiredAnnualSpending * Math.pow(1 + inflation, year);
    fiNumberTarget = inflatedSpendingThisYear / swr;

    // Portfolio growth: previous portfolio grows, then add savings
    projectedPortfolio = projectedPortfolio * (1 + rPreRetirement) + currentSavings;
    // Assuming currentSavings is nominal and added at year end. If savings inflate, adjust currentSavings here.

    portfolioGrowthChart.push({ name: age, Portfolio: parseFloat(projectedPortfolio.toFixed(2)), 'FI Target': parseFloat(fiNumberTarget.toFixed(2)) });

    if (!foundFI && projectedPortfolio >= fiNumberTarget) {
      yearsToFI = year;
      ageAtFI = age;
      foundFI = true;
      // Optional: if FI found, can break or continue projecting till desiredRetirementAge for chart
    }
    
    if (age >= currentAge + maxYears && !foundFI) { // Reached max projection and not FI
        yearsToFI = `Not within ${maxYears} years`;
        ageAtFI = `> ${currentAge + maxYears}`;
    }
  }

  const portfolioAtDesiredAgeEntry = portfolioGrowthChart.find(p => p.name === desiredRetirementAge);
  const projectedPortfolioAtDesiredRetirementValue = portfolioAtDesiredAgeEntry ? Number(portfolioAtDesiredAgeEntry.Portfolio) : projectedPortfolio;


  if (!foundFI && projectedPortfolio < fiNumberTarget) { // If loop finished and still not FI
      yearsToFI = `Not within projected ${maxYears} years`;
      ageAtFI = `Likely > ${currentAge + maxYears}`;
  }
   if (currentPortfolio >= (desiredAnnualSpending / swr) && currentAge <= desiredRetirementAge ) { // Already FI at start
    yearsToFI = "Already FI";
    ageAtFI = currentAge;
    fiNumberTarget = currentPortfolio * swr; // Effective current FI number met
  }


  return {
    fiNumber: parseFloat(Number(fiNumberTarget).toFixed(2)), 
    yearsToFI: yearsToFI,
    ageAtFI: ageAtFI,
    projectedPortfolioAtRetirement: parseFloat(Number(projectedPortfolioAtDesiredRetirementValue).toFixed(2)),
    portfolioGrowthChart,
  };
};

// Helper to format currency (can be moved to a utils file if it grows)
export const formatCurrency = (value: number, currencySymbol: string = '$'): string => {
  if (!isFinite(value)) return `${currencySymbol}Infinity`;
  return `${currencySymbol}${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};
