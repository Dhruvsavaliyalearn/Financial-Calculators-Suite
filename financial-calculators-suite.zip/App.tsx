
import React, { useState } from 'react';
import { CALCULATOR_TABS } from './constants';
import type { Tab } from './types';
import { CompoundInterestCalculator, CompoundInterestComparisonCalculator, MortgageVsInvestingCalculator, FinancialIndependenceCalculator } from './calculators/Calculators.tsx';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>(CALCULATOR_TABS[0].id);

  const renderActiveCalculator = () => {
    switch (activeTab) {
      case 'compoundInterest':
        return <CompoundInterestCalculator />;
      case 'compoundInterestComparison':
        return <CompoundInterestComparisonCalculator />;
      case 'mortgageVsInvesting':
        return <MortgageVsInvestingCalculator />;
      case 'financialIndependence':
        return <FinancialIndependenceCalculator />;
      default:
        return <p className="text-slate-400">Select a calculator from the tabs above.</p>;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-50 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <header className="w-full max-w-5xl mb-10 sm:mb-12 text-center">
        <h1 className="text-4xl sm:text-5xl font-bold text-emerald-400 tracking-tight">Financial Calculators Suite</h1>
        <p className="text-slate-300 mt-3 text-lg">Plan your financial future with our comprehensive set of tools.</p>
      </header>

      <div className="w-full max-w-5xl bg-slate-850 shadow-2xl rounded-lg">
        <nav className="flex flex-wrap border-b border-slate-700">
          {CALCULATOR_TABS.map((tab: Tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-3.5 px-4 sm:px-6 text-sm sm:text-base font-medium focus:outline-none transition-all duration-150 ease-in-out
                ${activeTab === tab.id 
                  ? 'border-b-2 border-emerald-500 text-emerald-400' 
                  : 'text-slate-400 hover:text-emerald-300 hover:bg-slate-700/60 rounded-t-md border-b-2 border-transparent'
                }`}
              aria-current={activeTab === tab.id ? 'page' : undefined}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        <main className="p-6 sm:p-8">
          {renderActiveCalculator()}
        </main>
      </div>
      
      <footer className="w-full max-w-5xl mt-12 text-center text-sm text-slate-500">
        <p>&copy; {new Date().getFullYear()} Financial Calculators Suite. For illustrative purposes only.</p>
        <p className="mt-1">Designed to help you make informed decisions.</p>
      </footer>
    </div>
  );
};

export default App;